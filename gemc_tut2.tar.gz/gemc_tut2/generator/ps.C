#include <iostream>
#include <fstream>

void ps(Int_t nev = 1000){
	TRandom3 *rand = new TRandom3();
	TLorentzVector p, k, kp, pp;
	
	Float_t me = 0.000511;
	Float_t mp = 0.938272;
	Float_t beamE = 11.0;
	
	Float_t mT = mp; //Set the mass of the target here
	Float_t qT = 1.0; //Set the charge of the target here.
		
	ofstream lundfile("ps.lund"); //For output lund file
	
	for(Int_t i =0; i < nev; i++){
		rand->SetSeed(i + 154521);
		
		//Throw flat in cos(theta) and forward
		Float_t cth = rand->Uniform(0.0,1.0);
		//calc the scattered electron energy from cos(theta) and the beam energy
		Float_t kpE = mT*beamE/(beamE - beamE*cth + mT);
		
		//set the 4 vectors for the proton, the beam electron and the scattered electron:
		
		p.SetXYZM(0.0,0.0,0.0,mT);
		k.SetXYZM(0.0,0.0,beamE, me);
		// Set scattered electron, and then rotate to correct angle
		kp.SetXYZM(0.0,0.0,kpE,me);
		kp.RotateY(acos(cth));
		
		//scattered proton follows from 4-vector addition:
		
		pp = p + k - kp;
		
		//Now generate a random azimuthal angle phi, and rotate scattered vectors about z:
		
		Float_t ph = rand->Uniform(0.0,2.0*TMath::Pi());
		kp.RotateZ(ph);
		pp.RotateZ(ph);
		
		//If we have done everything right, the mass of the scattered proton should be the proton mass.  Lets check:
		if(TMath::Abs(pp.M() - mp) > 0.0001){
			cout << "problem in scattered proton mass: " << pp.M() << endl;
		}
		
		//Now we need to output to a lund file
		//Find the correct format at:
		
		lundfile << "2  1.  1.  0.  0.  0.  0.  0.  0.  0." << endl; //Only the first and 5th entries matter (number of particles in event and beam polarization).
		lundfile << "  1  -1.  1  11  0  0  " << kp.X() << "  " << kp.Y() << "  " << kp.Z() << "  " << kp.E() << "  " << me << "  0.0  0.0  0.0" << endl;
		// The above line is the first scattered particle (electron), and it has 14 variables listed in order here (important variables MUST have relevant values, everything else could be set to zero):
		// 1:  index
		// 2:  charge
		// 3:  type (important to have as "1" if you want the particle reconstructed)
		// 4:  particle idendification number  (important:  Use PDG numbering format)
		// 5:  parent id
		// 6:  daughter id
		// 7:  Px [GeV] (important)
		// 8:  Py [Gev] (important)
		// 9:  Pz [GeV] (important)
		// 10: E  [GeV]
		// 11: mass  [GeV]
		// 12: x vertex [cm] (important)
		// 13: y vertex [cm] (important)
		// 14: z vertex [cm] (important)
		lundfile << "  2  " << qT << "  1  2212  0  0  " << pp.X() << "  " << pp.Y() << "  " << pp.Z() << "  " << pp.E() << "  " << mT << " 0.0  0.0  0.0" << endl;
		//above line is for proton (or scattered nucleus).
	}
	lundfile.close();	
}