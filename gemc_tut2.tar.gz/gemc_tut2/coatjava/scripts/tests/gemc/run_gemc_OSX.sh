#!/bin/sh

/Applications/gemc-2.0.app/gemc.app/Contents/MacOs/gemc.command clas12.gcard -N=1000
