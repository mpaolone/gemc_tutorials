#!/bin/sh

/Applications/gemc-2.2.app/gemc.app/Contents/MacOs/gemc.command clas12.gcard -INPUT_GEN_FILE="LUND, four_particle_sample_00001.lund" -N=200
