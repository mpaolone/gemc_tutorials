#!/bin/sh

/Applications/gemc-devel.app/gemc.app/Contents/MacOs/gemc.command clas12.gcard -USE_GUI=0 -INPUT_GEN_FILE="LUND, input.lund" -N=200
