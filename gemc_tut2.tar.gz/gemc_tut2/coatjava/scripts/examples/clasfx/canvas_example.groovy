//-----------------------------------------------------------
// Example Groovy class that extends the ClasReconstruction
// class and implements all abstruct methods. The reader runs
// the processEvent method for each event in the file. 
//
// author: gavalian date: 10/02/2014
//-----------------------------------------------------------


import org.clasfx.root.*;
import org.root.histogram.*;

TCanvas c1 = new TCanvas();
//H1D h1d = new H1D("h1d",200,0.0,14.0);
//c1.draw(h1d);
//c1.divide(3,2);

//TCanvasStage stage = new TCanvasStage();
