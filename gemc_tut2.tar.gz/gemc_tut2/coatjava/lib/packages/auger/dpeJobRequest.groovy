

System.out.print("<Request>\n");
System.out.print("<Project name=\"clas12\"/>\n");
System.out.print("<Track name=\"reconstruction\"/>\n");
System.out.print("<Name name=\"CLARA-DPE\"/>\n");
System.out.print("<CPU core=\"24\"/>\n");
System.out.print("<OS name=\"centos65\"/>\n");
System.out.print("<Memory space=\"8\" unit=\"GB\"/>\n");
System.out.print("<TimeLimit time =\"3\" unit=\"days\"/>\n");
System.out.print("<Command><![CDATA[\n/group/clas12/packages/coatjava-2.0/bin/clara-dpe -host 129.57.28.27\n]]></Command>\n");
//System.out.println("");
System.out.print("</Request>\n");
