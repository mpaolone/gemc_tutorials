import clasgemc.detector.*

//pcal = new PCAL();
//pcal.printPCAL();

ec = new EC();
ec.printEC();
